import streamlit as st
import app

txt_input=st.text_input(label="Ask anything here...")
if txt_input !="":
    
    response=app.semantic_search(txt_input)
    st.write(response)